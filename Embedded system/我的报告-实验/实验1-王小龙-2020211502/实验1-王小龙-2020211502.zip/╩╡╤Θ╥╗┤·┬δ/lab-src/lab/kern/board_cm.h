/*
 * board_cm.h
 *
 *  Created on: 2021年10月2日
 *      Author: ljp
 */

#ifndef BOARD_CM_H_
#define BOARD_CM_H_


#ifdef STM32F407xx
#include "stm32f4xx_hal.h"
#endif
#ifdef STM32F10X_MD
#include "stm32f1xx_hal.h"
#endif



#endif /* BOARD_CM_H_ */
