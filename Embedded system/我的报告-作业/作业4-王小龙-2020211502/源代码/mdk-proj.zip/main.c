#include <stdio.h>
#include "Board_LED.h" // ::Board Support:LED
#include "stm32f10x.h" // Device header
volatile uint32_t msTicks; // counts 1ms timeTicks
//update SysTick count
void SysTick_Handler(void) {
 msTicks++;
}
void Delay (uint32_t dlyTicks) {
 uint32_t curTicks;
 curTicks = msTicks;
 while ((msTicks - curTicks) < dlyTicks) { __NOP(); }
}
#define DELAY_TICKS 10
void different_manchester_encode(char ch){
	int flag;
	printf("%c: ", ch);
	int bit = (ch>>7) &0x01;
	if(bit == 0){			
		flag = 1;
		LED_Off(0);
		Delay(DELAY_TICKS);
		LED_On(0);
		Delay(DELAY_TICKS);
		printf("_|-");
	}
	else{						
		flag = 0;
		LED_On(0);
		Delay(DELAY_TICKS);
		LED_Off(0);
		Delay(DELAY_TICKS);
		printf("-|_");
	}
	for(int i = 6; i >= 0; i--){
		bit = (ch>>i) &0x01;
		if(bit == 0){
			if(flag == 0){
				LED_On(0);
				Delay(DELAY_TICKS);
				LED_Off(0);
				Delay(DELAY_TICKS);
				printf("|-|_");
			}
			else{
				LED_Off(0);
				Delay(DELAY_TICKS);
				LED_On(0);
				Delay(DELAY_TICKS);
				printf("|_|-");
			}
		}
		else{
			if(flag == 0){
				flag = 1;
				LED_Off(0);
				Delay(DELAY_TICKS);
				LED_On(0);
				Delay(DELAY_TICKS);
				printf("_|-");
			}
			else{
				flag = 0;
				LED_On(0);
				Delay(DELAY_TICKS);
				LED_Off(0);
				Delay(DELAY_TICKS);
				printf("-|_");
			}
		}
	}
	printf("\r\n");
}
void manchester_encode(char ch) {
	printf("%c: ", ch);
	for(int i = 7; i >= 0; i--) { //check each bit
		int bit = (ch >> i) & 0x1;
		if(bit == 0) { //0:low-high
			LED_Off(0);
			Delay(DELAY_TICKS);
			LED_On(0);
			Delay(DELAY_TICKS);
			printf("_-");
		} else { //1:high-low
			LED_On(0);
			Delay(DELAY_TICKS);
			LED_Off(0);
			Delay(DELAY_TICKS);
			printf("-_");
		}
	}
	printf("\r\n");
}
void str_encode(char * str) {
	while(*str) {
		//manchester_encode(*str++);
		different_manchester_encode(*str++);
	}
}
char* _strcpy(char *to, const char *from) {
	if(to == 0 || from == 0) {
		return 0;
	}
	char *p = to;
	while ((*p++ = *from++) != 0);
	return to;
}
int main() {
  SystemCoreClockUpdate(); // configure HSI as System Clock
  LED_Initialize(); //Enable LED(GPIOA.5)
  SysTick_Config(SystemCoreClock / 1000); // SysTick 1 msec interrupts
	char a[100];
	_strcpy(a+50,a);
	//while(1) {
		//str_encode("Hello, World\r\n");
	//}
}