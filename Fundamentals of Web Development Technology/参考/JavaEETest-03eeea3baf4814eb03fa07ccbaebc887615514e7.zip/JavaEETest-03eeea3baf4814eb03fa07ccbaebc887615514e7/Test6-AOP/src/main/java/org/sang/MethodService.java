package org.sang;

import org.springframework.stereotype.Service;

/**
 * Created by sang on 16-12-12.
 */
@Service
public class MethodService {
    public void add() {
        System.out.println("method-add()");
    }
}
