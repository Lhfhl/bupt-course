package org.sang;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/**
 * Created by sang on 16-12-13.
 */
//@Scope("singleton")
@Component
@Scope("prototype")
public class ScopeTest {

}
