package org.sang;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Test20WebSocketApplication {

	public static void main(String[] args) {
		SpringApplication.run(Test20WebSocketApplication.class, args);
	}
}
