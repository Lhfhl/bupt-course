package org.sang;

/**
 * Created by sang on 16-12-12.
 */
public class FunctionService {
    public String sayHello(String word) {
        return "你好 " + word + " !";
    }
}
